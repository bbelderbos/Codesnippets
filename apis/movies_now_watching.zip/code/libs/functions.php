<?php
function get_n_words($string, $number_of_words){
   $retval = $string; // Just in case of a problem
   $array = explode(" ", $string);
   if (count($array)<=$number_of_words)
   /* Already short enough, return the whole thing */
   {
      $retval = $string;
   }
   else
   /* Need to chop of some words */
   {
      array_splice($array, $number_of_words);
      $retval = implode(" ", $array)."";
   }
   return $retval;
}
?>