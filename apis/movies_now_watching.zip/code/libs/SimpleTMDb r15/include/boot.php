<?php
/**
 * @package SimpleTMDb
 * @author Dan Bettles <dan@danbettles.net>
 * @copyright Dan Bettles
 * @license BSD http://www.opensource.org/licenses/bsd-license.php
 */

require_once dirname(__DIR__) . '/vendor/TMDb-PHP-API/TMDb.php';

require_once __DIR__ . '/ApiNamespace.php';
require_once __DIR__ . '/apinamespace/Movie.php';
require_once __DIR__ . '/apinamespace/Person.php';

require_once __DIR__ . '/Tmdb.php';