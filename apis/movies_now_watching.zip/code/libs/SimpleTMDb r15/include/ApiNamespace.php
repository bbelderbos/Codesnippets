<?php
/**
 * @package SimpleTMDb
 * @author Dan Bettles <dan@danbettles.net>
 * @copyright Dan Bettles
 * @license BSD http://www.opensource.org/licenses/bsd-license.php
 */

namespace simpletmdb;

/**
 * @author Dan Bettles <dan@danbettles.net>
 */
abstract class ApiNamespace
{
    /**
     * @var simpletmdb\Tmdb
     */
    private $oTmdb;

    /**
     * @var string
     */
    private $pluralName;

    /**
     * @param simpletmdb\Tmdb $p_oTmdb
     */
    public function __construct(Tmdb $p_oTmdb)
    {
        $this->setTmdb($p_oTmdb);

        $this->initialize();
    }

    /**
     * Called on construction
     * 
     * Override this method to perform additional, custom initialization.  Overriding this method, rather than the
     * constructor with all its parameters, is quick and painless.
     */
    protected function initialize()
    {
    }

    /**
     * @param simpletmdb\Tmdb $p_oTmdb
     */
    private function setTmdb(Tmdb $p_oTmdb)
    {
        $this->oTmdb = $p_oTmdb;
    }

    /**
     * @return simpletmdb\Tmdb
     */
    public function getTmdb()
    {
        return $this->oTmdb;
    }

    /**
     * Sets the plural name of the API namespace
     * 
     * @param string $p_pluralName
     */
    protected function setPluralName($p_pluralName)
    {
        $this->pluralName = $p_pluralName;
    }

    /**
     * Returns the plural name of the API namespace, which, by default, is the name of the class suffixed with "s"
     * 
     * @return string
     */
    protected function getPluralName()
    {
        if (isset($this->pluralName)) {
            return $this->pluralName;
        }

        return strtolower(array_pop(explode('\\', get_class($this) . 's')));
    }

    /**
     * Returns the result of calling the specified proxy method, a SimpleXMLElement on success, or FALSE otherwise
     * 
     * @param string $p_name
     * @param array [$p_aArgument=array()]
     * @return SimpleXMLElement|bool
     */
    private function callProxyMethod($p_name, array $p_aArgument = array())
    {
        $oProxy = $this->getTmdb()->getProxy();
        $oProxyMethod = new \ReflectionMethod($oProxy, $p_name);

        //The last parameter is always the format.  We will always _automatically_ request XML, so grab all parameters
        //before the last - at least as far as the proxy method is concerned.
        $aArgument = array_slice($p_aArgument, 0, $oProxyMethod->getNumberOfParameters() - 1);

        $aArgument[] = \TMDb::XML;

        $responseXml = empty($aArgument) ? $oProxyMethod->invoke($oProxy) : $oProxyMethod->invokeArgs($oProxy, $aArgument);

        if (is_string($responseXml) && strlen($responseXml)) {
            return new \SimpleXMLElement($responseXml);
        }

        return false;
    }

    /**
     * Returns the response body returned by the specified proxy method, a SimpleXMLElement on success, or FALSE
     * otherwise
     * 
     * @param string $p_name
     * @param array [$p_aArgument=array()]
     * @return SimpleXMLElement|bool
     */
    protected function responseBody($p_name, array $p_aArgument = array())
    {
        if ($oResponse = $this->callProxyMethod($p_name, $p_aArgument)) {
            $pluralName = $this->getPluralName();
            return $oResponse->$pluralName;
        }

        return $oResponse;
    }

    /**
     * Returns the first child of the response body returned by the specified proxy method, a SimpleXMLElement on
     * success, or FALSE otherwise
     * 
     * @param string $p_name
     * @param array [$p_aArgument=array()]
     * @return SimpleXMLElement|bool
     */
    protected function responseBodyFirstChild($p_name, array $p_aArgument = array())
    {
        if ($oResponseBody = $this->responseBody($p_name, $p_aArgument)) {
            $oChildren = $oResponseBody->children();
            return $oChildren[0];
        }

        return $oResponseBody;
    }
}