<?php
/**
 * @package SimpleTMDb
 * @author Dan Bettles <dan@danbettles.net>
 * @copyright Dan Bettles
 * @license BSD http://www.opensource.org/licenses/bsd-license.php
 */

namespace simpletmdb;

/**
 * Wrapper for Jonas De Smet's (Glamorous) TMDb PHP API class
 * 
 * @author Dan Bettles <dan@danbettles.net>
 */
class Tmdb
{
    /**
     * @var TMDb
     */
    private $oProxy;

    /**
     * @var simpletmdb\apinamespace\Movie
     */
    public $Movie;

    /**
     * @var simpletmdb\apinamespace\Person
     */
    public $Person;

    /**
     * @param TMDb $p_oProxy
     */
    public function __construct(\TMDb $p_oProxy)
    {
        $this->setProxy($p_oProxy);

        //@todo Sort these out
        $this->Movie = new \simpletmdb\apinamespace\Movie($this);
        $this->Person = new \simpletmdb\apinamespace\Person($this);
    }

    /**
     * Returns a new instance
     * 
     * @param string $p_apiKey
     * @return simpletmdb\Tmdb
     */
    public static function create($p_apiKey)
    {
        return new self(new \TMDb($p_apiKey));
    }

    /**
     * @param TMDb $p_oProxy
     */
    private function setProxy(\TMDb $p_oProxy)
    {
        $this->oProxy = $p_oProxy;
    }

    /**
     * Returns the TMDb object used to create the object
     * 
     * @return TMDb
     */
    public function getProxy()
    {
        return $this->oProxy;
    }
}