<?php
/**
 * @package SimpleTMDb
 * @author Dan Bettles <dan@danbettles.net>
 * @copyright Dan Bettles
 * @license BSD http://www.opensource.org/licenses/bsd-license.php
 */

namespace simpletmdb\apinamespace;

/**
 * @author Dan Bettles <dan@danbettles.net>
 */
class Person extends \simpletmdb\ApiNamespace
{
    /**
     * @see parent::initialize()
     */
    protected function initialize()
    {
        $this->setPluralName('people');
    }

    /**
     * Searches for a person with the specified name, returning a SimpleXMLElement if successful, or FALSE otherwise
     * 
     * @param string $p_name
     * @return SimpleXMLElement|bool
     */
    public function search($p_name)
	{
        return $this->responseBody('searchPerson', array($p_name));
	}

    /**
     * Returns detailed information on the specified person, or FALSE if the request was unsuccessful
     * 
     * @param int $p_id
     * @return SimpleXMLElement|bool
     */
    public function getInfo($p_id)
    {
        return $this->responseBodyFirstChild('getPerson', array($p_id));
    }
}