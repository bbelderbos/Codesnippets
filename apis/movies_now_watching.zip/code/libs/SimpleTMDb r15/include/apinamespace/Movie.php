<?php
/**
 * @package SimpleTMDb
 * @author Dan Bettles <dan@danbettles.net>
 * @copyright Dan Bettles
 * @license BSD http://www.opensource.org/licenses/bsd-license.php
 */

namespace simpletmdb\apinamespace;

/**
 * @author Dan Bettles <dan@danbettles.net>
 */
class Movie extends \simpletmdb\ApiNamespace
{
    /**
     * Searches for a movie with the specified title, returning a SimpleXMLElement if successful, or FALSE otherwise
     * 
     * @param string $p_title
     * @return SimpleXMLElement|bool
     */
    public function search($p_title)
	{
        return $this->responseBody('searchMovie', array($p_title));
	}

    /**
     * Returns detailed information on the specified movie, identified by its IMDB ID, or FALSE if the request was
     * unsuccessful
     * 
     * @param int $p_imdbId
     * @return SimpleXMLElement|bool
     */
    public function imdbLookup($p_imdbId)
    {
        return $this->responseBodyFirstChild('getMovie', array($p_imdbId, \TMDb::IMDB));
    }

    /**
     * Returns detailed information on the specified movie, or FALSE if the request was unsuccessful
     * 
     * @param int $p_id
     * @return SimpleXMLElement|bool
     * @todo Call imdbLookup() if an IMDB ID is detected?
     */
    public function getInfo($p_id)
    {
        return $this->responseBodyFirstChild('getMovie', array($p_id, \TMDb::TMDB));
    }

    /**
     * Returns the images associated with the specified movie, identified by either its TMDb or IMDB ID, or FALSE if the
     * request was unsuccessful
     * 
     * @param int|string $p_id
     * @return SimpleXMLElement|bool
     */
    public function getImages($p_id)
    {
        return $this->responseBodyFirstChild('getImages', array($p_id));
    }
}