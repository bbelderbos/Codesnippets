<?php
/**
 * SimpleTmdb Demo
 * 
 * @author Dan Bettles <dan@danbettles.net>
 */

$title = basename(__FILE__, '.php') . ' Demo';

$oResults = false;

if (isset($_GET['sendRequest'])) {
    require_once dirname(dirname(__DIR__)) . '/include/boot.php';

    $oResults = simpletmdb\Tmdb::create($_GET['apiKey'])
        ->Movie
        ->getInfo($_GET['id']);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        <title><?php echo $title ?></title>
        <link rel="stylesheet" type="text/css" href="main.css" />
    </head>

    <body>
        <h1><?php echo $title ?></h1>

        <form method="get" action="<?php echo $_SERVER['PHP_SELF'] ?>">
            <p><label><span>API key</span><input type="text" name="apiKey" value="<?php echo isset($_GET['apiKey']) ? $_GET['apiKey'] : '' ?>" /></label></p>
            <p><label><span>ID</span><input type="text" name="id" /></label></p>
            <p><input type="submit" name="sendRequest" value="Go" /></p>
        </form>

        <?php if (isset($_GET['sendRequest'])) { ?>
            <?php if ($oResults) { ?>
                <div class="movie">
                    <h2>
                        <span class="id"><?php echo $oResults->id ?></span> -
                        <span class="name"><?php echo $oResults->name ?></span>
                    </h2>
    
                    <p>
                        <?php if ($oImages = $oResults->images->xpath("image[(@type = 'poster') and (@size = 'cover')]")) { ?>
                            <img src="<?php echo $oImages[0]['url'] ?>" alt="" class="thumbnail" />
                        <?php } ?>
    
                        <span class="overview"><?php echo $oResults->overview ?></span>
                    </p>

                    <?php if ($oResults->categories && ($oGenres = $oResults->categories->xpath("category[@type = 'genre']"))) { ?>
                        <p>Genres:</p>

                        <ul>
                            <?php foreach ($oGenres as $oGenre) { ?>
                            <li class="genre"><?php echo $oGenre['name'] ?></li>
                            <?php } ?>
                        </ul>
                    <?php } ?>
                </div>
            <?php } else { ?>
                <p>Movie not found</p>
            <?php } ?>
        <?php } ?>
    </body>
</html>