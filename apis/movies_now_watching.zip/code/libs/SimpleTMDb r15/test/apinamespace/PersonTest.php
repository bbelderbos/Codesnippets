<?php
/**
 * @author Dan Bettles <dan@danbettles.net>
 */

namespace simpletmdb\test\apinamespace\Person;

/**
 * @author Dan Bettles <dan@danbettles.net>
 */
class Test extends \PHPUnit_Framework_TestCase
{
    public function testIsAnApinamespace()
    {
        $oReflectionClass = new \ReflectionClass('simpletmdb\apinamespace\Person');
        $this->assertTrue($oReflectionClass->isSubclassOf('simpletmdb\ApiNamespace'));
    }

    public function testSearchReturnsASimplexmlelementObjectIfSuccessful()
    {
        $oProxy = new \simpletmdb\test\ProxyMock('apikey');

        $expectedXml = '<people><person>...</person></people>';

        $oProxy->responseXml = <<<END
<OpenSearchDescription xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">
    <opensearch:Query searchTerms="Nikolaj Lie Kaas"/>
    <opensearch:totalResults>1</opensearch:totalResults>
    {$expectedXml}
</OpenSearchDescription>
END;

        $oPerson = new \simpletmdb\apinamespace\Person(new \simpletmdb\Tmdb($oProxy));

        $this->assertEquals(new \SimpleXMLElement($expectedXml), $oPerson->search('Nikolaj Lie Kaas'));
    }

    public function testSearchReturnsFalseIfUnsuccessful()
    {
        $oProxy = new \simpletmdb\test\ProxyMock('apikey');
        $oProxy->responseXml = '';
        $oPerson = new \simpletmdb\apinamespace\Person(new \simpletmdb\Tmdb($oProxy));
    
        $this->assertFalse($oPerson->search(null));
    }

    public function testGetinfoReturnsASimplexmlelementObjectIfSuccessful()
    {
        $oProxy = new \simpletmdb\test\ProxyMock('apikey');

        $expectedXml = '<person><name>Nikolaj Lie Kaas</name></person>';

        $oProxy->responseXml = <<<END
<OpenSearchDescription xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">
    <opensearch:Query searchTerms=""/>
    <opensearch:totalResults>1</opensearch:totalResults>
    <people>
        {$expectedXml}
    </people>
</OpenSearchDescription>
END;

        $oPerson = new \simpletmdb\apinamespace\Person(new \simpletmdb\Tmdb($oProxy));

        $this->assertEquals(new \SimpleXMLElement($expectedXml), $oPerson->getInfo(1018));
    }

    public function testGetinfoReturnsFalseIfUnsuccessful()
    {
        $oProxy = new \simpletmdb\test\ProxyMock('apikey');
        $oProxy->responseXml = '';
        $oPerson = new \simpletmdb\apinamespace\Person(new \simpletmdb\Tmdb($oProxy));
    
        $this->assertFalse($oPerson->getInfo(null));
    }
}