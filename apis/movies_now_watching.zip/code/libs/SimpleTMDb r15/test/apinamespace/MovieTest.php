<?php
/**
 * @author Dan Bettles <dan@danbettles.net>
 */

namespace simpletmdb\test\apinamespace\Movie;

/**
 * @author Dan Bettles <dan@danbettles.net>
 */
class Test extends \PHPUnit_Framework_TestCase
{
    public function testIsAnApinamespace()
    {
        $oReflectionClass = new \ReflectionClass('simpletmdb\apinamespace\Movie');
        $this->assertTrue($oReflectionClass->isSubclassOf('simpletmdb\ApiNamespace'));
    }

    public function testSearchReturnsASimplexmlelementObjectIfSuccessful()
    {
        $oProxy = new \simpletmdb\test\ProxyMock('apikey');

        $expectedXml = '<movies><movie>...</movie></movies>';

        $oProxy->responseXml = <<<END
<OpenSearchDescription xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">
    <opensearch:Query searchTerms="Mulholland Drive"/>
    <opensearch:totalResults>1</opensearch:totalResults>
    {$expectedXml}
</OpenSearchDescription>
END;

        $oMovie = new \simpletmdb\apinamespace\Movie(new \simpletmdb\Tmdb($oProxy));

        $this->assertEquals(new \SimpleXMLElement($expectedXml), $oMovie->search('Mulholland Drive'));
    }

    public function testSearchReturnsFalseIfUnsuccessful()
    {
        $oProxy = new \simpletmdb\test\ProxyMock('apikey');
        $oProxy->responseXml = '';
        $oMovie = new \simpletmdb\apinamespace\Movie(new \simpletmdb\Tmdb($oProxy));

        $this->assertFalse($oMovie->search(''));
    }

    public function testImdblookupReturnsASimplexmlelementIfSuccessful()
    {
        $oProxy = new \simpletmdb\test\ProxyMock('apikey');

        $expectedXml = '<movie><name>Mulholland Drive</name></movie>';

        $oProxy->responseXml = <<<END
<OpenSearchDescription xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">
    <opensearch:Query searchTerms="tt0166924"/>
    <opensearch:totalResults>1</opensearch:totalResults>
    <movies>
        {$expectedXml}
    </movies>
</OpenSearchDescription>
END;

        $oMovie = new \simpletmdb\apinamespace\Movie(new \simpletmdb\Tmdb($oProxy));

        $this->assertEquals(new \SimpleXMLElement($expectedXml), $oMovie->imdbLookup('tt0166924'));
    }

    public function testImdblookupReturnsFalseIfUnsuccessful()
    {
        $oProxy = new \simpletmdb\test\ProxyMock('apikey');
        $oProxy->responseXml = '';
        $oMovie = new \simpletmdb\apinamespace\Movie(new \simpletmdb\Tmdb($oProxy));
    
        $this->assertFalse($oMovie->imdbLookup(null));
    }

    public function testGetinfoReturnsASimplexmlelementIfSuccessful()
    {
        $oProxy = new \simpletmdb\test\ProxyMock('apikey');

        $expectedXml = '<movie><name>Mulholland Drive</name></movie>';

        $oProxy->responseXml = <<<END
<OpenSearchDescription xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">
    <opensearch:Query searchTerms="1018"/>
    <opensearch:totalResults>1</opensearch:totalResults>
    <movies>
        {$expectedXml}
    </movies>
</OpenSearchDescription>
END;

        $oMovie = new \simpletmdb\apinamespace\Movie(new \simpletmdb\Tmdb($oProxy));

        $this->assertEquals(new \SimpleXMLElement($expectedXml), $oMovie->getInfo(1018));
    }

    public function testGetinfoReturnsFalseIfUnsuccessful()
    {
        $oProxy = new \simpletmdb\test\ProxyMock('apikey');
        $oProxy->responseXml = '';
        $oMovie = new \simpletmdb\apinamespace\Movie(new \simpletmdb\Tmdb($oProxy));

        $this->assertFalse($oMovie->getInfo(null));
    }

    public function testGetimagesReturnsASimplexmlelementIfSuccessful()
    {
        $oProxy = new \simpletmdb\test\ProxyMock('apikey');

        $expectedXml = '<movie><images></images></movie>';

        $oProxy->responseXml = <<<END
<OpenSearchDescription xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">
    <opensearch:Query searchTerms="1018"/>
    <opensearch:totalResults>1</opensearch:totalResults>
    <movies>
        {$expectedXml}
    </movies>
</OpenSearchDescription>
END;

        $oMovie = new \simpletmdb\apinamespace\Movie(new \simpletmdb\Tmdb($oProxy));

        $this->assertEquals(new \SimpleXMLElement($expectedXml), $oMovie->getImages(1018));
    }

    public function testGetimagesReturnsFalseIfUnsuccessful()
    {
        $oProxy = new \simpletmdb\test\ProxyMock('apikey');
        $oProxy->responseXml = '';
        $oMovie = new \simpletmdb\apinamespace\Movie(new \simpletmdb\Tmdb($oProxy));
    
        $this->assertFalse($oMovie->getImages(null));
    }
}