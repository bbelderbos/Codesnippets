<?php
/**
 * @author Dan Bettles <dan@danbettles.net>
 */

namespace simpletmdb\test;

require_once dirname(__DIR__) . '/include/boot.php';

//@todo TMDb should handle validation.  The main thing, here, is to ensure that the requested format is always XML.
class ProxyMock extends \TMDb
{
    public $responseXml;

    public function searchMovie($title, $format = null)
    {
        if (is_string($title) && strlen($title) && ($format == self::XML)) {
            return $this->responseXml;
        }

        return false;
    }

	public function getMovie($id, $type = \TMDb::TMDB, $format = null)
	{
        if (($type == \TMDb::TMDB) && ! is_numeric($id)) {
            return false;
        }

        if (($type == \TMDb::IMDB) && ! is_string($id)) {
            return false;
        }

        if ($format == self::XML) {
            return $this->responseXml;
        }

        return false;
	}

    public function getImages($id, $format = null)
    {
        if ((is_numeric($id) || is_string($id)) && ($format == self::XML)) {
            return $this->responseXml;
        }

        return false;
    }

    public function searchPerson($name, $format = null)
    {
        if (is_string($name) && strlen($name) && ($format == self::XML)) {
            return $this->responseXml;
        }

        return false;
    }

    public function getPerson($id, $format = null)
    {
        if (is_numeric($id) && ($format == self::XML)) {
            return $this->responseXml;
        }

        return false;
    }
}