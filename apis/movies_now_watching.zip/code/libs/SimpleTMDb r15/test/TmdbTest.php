<?php
/**
 * @author Dan Bettles <dan@danbettles.net>
 */

namespace simpletmdb\test\Tmdb;

/**
 * @author Dan Bettles <dan@danbettles.net>
 */
class Test extends \PHPUnit_Framework_TestCase
{
    public function testIsConstructedWithAProxyObject()
    {
        $oProxy = new \TMDb('apikey');
        $oTmdb = new \simpletmdb\Tmdb($oProxy);

        $this->assertSame($oProxy, $oTmdb->getProxy());
    }

    public function testCreateReturnsANewInstance()
    {
        $apiKey = 'apikey';
        $oTmdb = \simpletmdb\Tmdb::create($apiKey);

        $this->assertTrue($oTmdb instanceof \simpletmdb\Tmdb);
        $this->assertEquals($apiKey, $oTmdb->getProxy()->getApiKey());
    }

    public function testTheMoviePropertyIsAMovieApinamespace()
    {
        $oTmdb = \simpletmdb\Tmdb::create('apikey');

        $this->assertTrue($oTmdb->Movie instanceof \simpletmdb\apinamespace\Movie);
    }

    public function testThePersonPropertyIsAPersonApinamespace()
    {
        $oTmdb = \simpletmdb\Tmdb::create('apikey');

        $this->assertTrue($oTmdb->Person instanceof \simpletmdb\apinamespace\Person);
    }
}