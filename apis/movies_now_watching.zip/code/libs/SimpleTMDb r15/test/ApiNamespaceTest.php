<?php
/**
 * @author Dan Bettles <dan@danbettles.net>
 */

namespace simpletmdb\test\ApiNamespace;

/**
 * @author Dan Bettles <dan@danbettles.net>
 */
class Test extends \PHPUnit_Framework_TestCase
{
    public function testIsAbstract()
    {
        $oReflectionClass = new \ReflectionClass('simpletmdb\ApiNamespace');
        $this->assertTrue($oReflectionClass->isAbstract());
    }

    public function testIsConstructedWithATmdbObject()
    {
        $oTmdb = \simpletmdb\Tmdb::create('apikey');
        $oEmptyApiNamespace = new EmptyApiNamespace($oTmdb);

        $this->assertSame($oTmdb, $oEmptyApiNamespace->getTmdb());
    }

    public function testInitializeIsCalledOnConstruction()
    {
        $oTestApiNamespace02 = new ApiNamespace02(\simpletmdb\Tmdb::create('apikey'));

        $this->assertTrue($oTestApiNamespace02->initializeCalled);
    }

    public function testResponsebodyReturnsTheResultOfCallingTheSpecifiedProxyMethod()
    {
        $oProxy = new \simpletmdb\test\ProxyMock('apikey');

        $expectedXml = '<movies><movie>...</movie></movies>';

        $oProxy->responseXml = <<<END
<OpenSearchDescription xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">
    <opensearch:Query searchTerms="Mulholland Drive"/>
    <opensearch:totalResults>1</opensearch:totalResults>
    {$expectedXml}
</OpenSearchDescription>
END;

        $oMovieNamespace = new Movie(new \simpletmdb\Tmdb($oProxy));
        $result = $oMovieNamespace->responseBody('searchMovie', array('Mulholland Drive'));

        $this->assertEquals(new \SimpleXMLElement($expectedXml), $result);

        $expectedXml = '<movies><movie>...</movie></movies>';

        $oProxy->responseXml = <<<END
<OpenSearchDescription xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">
    <opensearch:Query searchTerms="1018"/>
    <opensearch:totalResults>1</opensearch:totalResults>
    {$expectedXml}
</OpenSearchDescription>
END;

        $oMovieNamespace = new Movie(new \simpletmdb\Tmdb($oProxy));

        //Note the 'invalid' format
        $result = $oMovieNamespace->responseBody('getMovie', array(1018, \TMDb::TMDB, \TMDb::JSON));

        $this->assertEquals(new \SimpleXMLElement($expectedXml), $result);

        $expectedXml = '<people><person>...</person></people>';

        $oProxy->responseXml = <<<END
<OpenSearchDescription xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">
    <opensearch:Query searchTerms="Nikolaj Lie Kaas"/>
    <opensearch:totalResults>1</opensearch:totalResults>
    {$expectedXml}
</OpenSearchDescription>
END;

        $oPersonNamespace = new Person(new \simpletmdb\Tmdb($oProxy));
        $result = $oPersonNamespace->responseBody('searchPerson', array('Nikolaj Lie Kaas'));

        $this->assertEquals(new \SimpleXMLElement($expectedXml), $result);
    }
}

class EmptyApiNamespace extends \simpletmdb\ApiNamespace
{
}

class ApiNamespace02 extends \simpletmdb\ApiNamespace
{
    public $initializeCalled = false;

    protected function initialize()
    {
        $this->initializeCalled = true;
    }
}

class ApiNamespace03 extends \simpletmdb\ApiNamespace
{
    public function responseBody($p_name, array $p_aArgument = array())
    {
        return parent::responseBody($p_name, $p_aArgument);
    }
}

class Movie extends ApiNamespace03
{
}

class Person extends ApiNamespace03
{
    protected function initialize()
    {
        $this->setPluralName('people');
    }
}