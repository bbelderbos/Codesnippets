<?php
$key = 'ec67390edfcb4ea6e5a5236251968a0c';

$movie = $_POST['movieId'];
$name = $_POST['movieName'];

$query = "http://api.themoviedb.org/2.1/Movie.getInfo/en/json/$key/$movie";

$info = file_get_contents($query, true);
$info = json_decode($info);
//echo "<pre>"; print_r($info); echo "</pre>"; exit; 

foreach($info as $item) {
	
	if(isset($item->trailer)) {
		$url = str_replace('www.','',$item->trailer);
		$extraInfo = ' / trailer: '.$url;
	} else {		
		if(isset($item->imdb_id)) {
			$url = 'http://imdb.com/title/' . $item->imdb_id;
			$extraInfo =  ' / imdb: ' . $url ; 
		} else {
			$url = '';
			$extraInfo = '';
		}
	}
	
	if(isset($item->posters[0]->image->url)) {
		$fbImg = $item->posters[0]->image->url;
	} else {
		$fbImg = "http://sharemovi.es/i/logoS.jpg";
	}
}


?>
<h2>Share this!</h2>
<form action="#"  method="post" id="comment">
<textarea readonly="readonly" col="20" row="10" name="status" id="status">#nw <?php echo $name  . $extraInfo; ?> (via @sharemovies)</textarea>
<a href="#" id="statusEdit"><img src="i/edit.png" alt="edit button"></a>
<div id="btnWrapper">
	<input type="submit" class="submit" id="facebook" name="facebook" value="Facebook">
	<input type="submit" class="submit" id="twitter" name="twitter" value="Tweet">
</div>
<input type="hidden" id="fbUrl" name="fbUrl" value="<?php echo $url; ?>">
<input type="hidden" id="fbTitle" name="fbTitle" value="<?php echo $name; ?>">
<input type="hidden" id="fbImg" name="fbImg" value="<?php echo $fbImg; ?>">

</form>