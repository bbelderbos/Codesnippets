<?php
$key = 'ec67390edfcb4ea6e5a5236251968a0c';
$movie = '550';

$query = "http://api.themoviedb.org/2.1/Movie.getInfo/en/json/$key/$movie";

$info = file_get_contents($query, true);
$info = json_decode($info);

foreach($info as $item) {
	echo $item->posters[0]->image->url; 
}

echo "<hr>"; 

echo "<pre>"; print_r($info); echo "</pre>"; exit;