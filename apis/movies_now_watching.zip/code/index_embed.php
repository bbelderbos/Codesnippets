<!DOCTYPE html>
<html>
<head>
	<title>Sharemovi.es - What #movie are you #nw ?</title>
  <link rel="stylesheet" type="text/css" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1/themes/redmond/jquery-ui.css">
  <link rel="stylesheet" type="text/css" href="reset.css">
  <link rel="stylesheet" type="text/css" href="style.css">

	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
	<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js"></script>
	<script src="base.js"></script>
</head>
<body>
  
<div id="searchForm">
	<form action="#"  method="post">

		<p class="ui-widget">
		<input type="text" id="autocomplete"  name="autocomplete" class="defaultText" title="What movie are you watching? "/> 
		<div class="spinner"><img src="i/ajax-loader.gif"></div>
		</p>

		<!--<p><input type="submit" name="submitBtn" value="Submit" /></p>-->
	</form>
</div>

<div id="commentWrapper"></div>




</body>
</html>

