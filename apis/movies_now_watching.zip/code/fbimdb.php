<?php
$q = $_GET['q'];
if(strstr($q, 'imdb')) {

$imdbUrl = "https://graph.facebook.com/?ids=http://www.imdb.com/title/$q/"; 

	$obj = @json_decode(file_get_contents('https://graph.facebook.com/?ids=' . $q));
	

	$name = @$obj->{$q}->{'name'}; 
	$pic = @$obj->{$q}->{'picture'}; 
	$descr = @$obj->{$q}->{'description'}; 

	if($name == "" || $pic == "" ||$descr == "" ) {
		echo '<li>Nothing found in IMDB, please submit the correct IMDB link, <br>in this format http://www.imdb.com/title/tt1375666/</li>';
	} else {
		echo '<li><img class="poster" src="'.$pic.'" alt="poster of '.$name.'" /></li><li><h2>'.$name.'</h2></li>
			<li><p class="reviewDescr">'.$descr.' <a href="'.$q.'" title="more info on IMDB.." target="blank">
				more ..</a></p></li>
			<input type="hidden" name="title" id="title" value="'.$name.'">
			<input type="hidden" name="pic" id="pic" value="'.$pic.'">
			<input type="hidden" name="descr" id="descr" value="'.$descr.'">
			';
	}


}
?>
