<?php
if (!$_POST["q"]) return;

$q = str_replace(" ","+", $_POST["q"]);
$q .="+trailer";

$yql = "select * from youtube.search where query='$q' limit 5";  
$query = "http://query.yahooapis.com/v1/public/yql?q=";
$query .= urlencode($yql);
$query .= "&format=json&env=store://datatables.org/alltableswithkeys";
$videos = file_get_contents($query, true);

$videos = json_decode($videos);
//echo "<pre>"; print_r($videos->query->results->video); echo "</pre>"; exit; 

$counter = 0; 
if(isset($videos->query->results->video)) {
	foreach($videos->query->results->video as $item) {
		if(isset($item->id)) {
			echo '<iframe width="300" height="150" src="http://www.youtube.com/embed/'.$item->id.'?fs=1&autoplay=1&loop=1&controls=0" frameborder="0" allowfullscreen></iframe>';
		} else {
			echo 'Video not found';
		}
	
		break;		

	}
} else {
	echo 'Video not found';
}
?>