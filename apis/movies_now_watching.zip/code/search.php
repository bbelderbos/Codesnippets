<?php
include('libs/functions.php');
$term = str_replace(" ","+", $_GET["term"]);
if (!$term) return;

include 'libs/glamorous-TMDb-PHP-API-9707495/TMDb.php'; 

// https://github.com/glamorous/TMDb-PHP-API
$tmdb = new TMDb('---'); //change 'API-key' with yours

//Search Movie with default return format
$resultJson = $tmdb->searchMovie($term, TMDb::JSON);
$resultJsonDecoded = json_decode($resultJson);
//echo "<pre>"; print_r($resultJsonDecoded); echo "</pre>"; exit; 

// formatting in JS :
// http://stackoverflow.com/questions/6070142/jquery-ui-formatting-the-autocomplete-results-add-image-possible
$counter = 0; // why does moviedb api not have limit ?!
$return_arr = array();

if(isset($resultJsonDecoded[0]) && $resultJsonDecoded[0] == "Nothing found.") {
	array_push($return_arr, $resultJsonDecoded[0]); 
} else {
	foreach($resultJsonDecoded as $movie) {
			$counter++; 
	   	$row_array['id'] = $movie->id;
			$row_array['value'] = ucwords($movie->name); 
			if($movie->name != $movie->original_name) {
				$row_array['value'] .= " (".$movie->original_name.")"; 
			}
			$row_array['rating'] = $movie->rating;
			$row_array['plot'] = get_n_words($movie->overview, 15) . " ..." ;
			$row_array['year'] = substr($movie->released, 0, 4);
			if(isset($movie->posters[0]->image->url)) $row_array['img'] = $movie->posters[0]->image->url;
			array_push($return_arr,$row_array);
			if($counter == 5) break;
	}
}

echo json_encode($return_arr);
?>
