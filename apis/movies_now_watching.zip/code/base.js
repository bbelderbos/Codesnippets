$(document).ready(function() {
	$('.spinner').hide();
	$('#commentWrapper').hide();
	//$("form#comment").hide();
	
  $("input#autocomplete").autocomplete({	
		search: function(event, ui) { 
       $('.spinner').show();
  	},
  	open: function(event, ui) {
       $('.spinner').hide();
  	},	
		source: "search.php",
		minLength: 2,
		select: function(event, ui) { 
			var selectedMovieId = ui.item.id;
			$('.spinner').show();
			
			$.post("comment.php",
				{ movieName: ui.item.value, movieId: selectedMovieId },	function(data){
					$("#commentWrapper").slideDown(function(){
						$(this).html(data);
						$(".trailer").html('<img src="i/youtube.png">');
						$('.spinner').hide();
					}); 
				}
			);
		}
	}).data( "autocomplete" )._renderItem = function( ul, item ) {
		if(item.value == "Nothing found.") {
			return $( "<h2 class='notfound'></h2>" )
      .data( "item.autocomplete", item )
      .append( "<p>"+item.value+"</p>" )
      .appendTo( ul );

		} else {
			return $( "<li></li>" )
      .data( "item.autocomplete", item )
      .append( "<a id="+item.id+">" + "<img src='" + item.img + "' /><span>" + item.value+ "<small><br>Year: "+item.year+"  <br>Rating: "+item.rating+"<br><small>Plot: "+item.plot+"</small><div id='"+item.value+"'  class='trailer'><img src='i/youtube.png'></div></small></span></a>" )
      .appendTo( ul );
		}
		

	 };
	
	
	// http://www.dailycoding.com/Posts/default_text_fields_using_simple_jquery_trick.aspx

	$(".defaultText").live('focus', function(srcc)
  {
      if ($(this).val() == $(this)[0].title)
      {
          $(this).removeClass("defaultTextActive");
          $(this).val("");
      }
  });

  $(".defaultText").live('blur', function(e)
  {
      if ($(this).val() == "")
      {
          $(this).addClass("defaultTextActive");
          $(this).val($(this)[0].title);
      }
  });
	
	$(".defaultText").live().blur(); // ??
	
	
	$('li').live('mouseenter', function(e) { 	
		var movie = $(this).find('div');
		var movieName = movie.attr('id');
		
		$.post("youtube.php",
			{ q: movieName},	function(data){
				$(".trailer").html('<img src="i/youtube.png">');
				movie.html(data); 
			}
		);
		e.preventDefault();
	});
	
	
	$('li').live('mouseleave', function(e) { 	
		$(".trailer").html('<img src="i/youtube.png">');
	});
	
		
	$('.submit').live('click', function(){
		var medium = $(this).attr('name');
		var statusVal = encodeURIComponent($("#status").val());
				
		var fbUrl = $("#fbUrl").val();
		var fbTitle = $("#fbTitle").val();
		var fbImg = $("#fbImg").val();
		
		switch(medium) {
   		case 'twitter': 
				urlToGo = "https://twitter.com/home?status="+statusVal;
   			break;
   		case 'facebook': 
				//urlToGo = "https://facebook.com/sharer.php?u="+fbUrl+"&t="+fbTitle;
				
				var hostName = location.host;
		
				if(hostName == '192.168.1.45:8888') {
					var callbackUrl = hostName+"/sharemovies/";
					var app_id = '188495167831276';
				} else {
					var callbackUrl = hostName;
					var app_id = '145334765507139';
				}
				
   			urlToGo = 'https://www.facebook.com/dialog/feed?app_id='+app_id+'&link='+fbUrl+'&picture='+fbImg+'&name=Now%20Watching%3A%20'+fbTitle+'&description='+statusVal+'&message=&redirect_uri=http://'+callbackUrl;
				break;
   	}

		window.open(urlToGo, '_blank');
		//window.open(urlToGo, 'sharer', 'toolbar=0,status=0,width=900,height=400');
		
		return false; 
		
	});
	
	
	$('#statusEdit').live('click', function() 
	{ 
		$('#status').css("background-color","#ffffff");
	  $('#status').removeAttr("readonly"); 
	});
	
	
	
});