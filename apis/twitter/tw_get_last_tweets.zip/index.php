<?php include 'yql.php'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Last Tweets @bbelderbos</title>
	<link rel="stylesheet" href="style.css" type="text/css" media="screen"/>
	
	<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
	<script type="text/javascript" src="js/jquery.tinycarousel.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#slider1').tinycarousel({ pager: true, interval: true, intervaltime: 5000  });	
		});
	</script>	
		
</head>
<body>
	<div id="slider1">
		<div class="viewport">
			<ul class="overview">
				<?php 
				foreach($info['query']['results']['results'] as $tweet) {
					$tweetText = $tweet['text'];
					$avatar = $tweet['profile_image_url'];

					// URLs (from http://www.phpro.org/examples/URL-to-Link.html)
					$tweetText = preg_replace("/([\w]+:\/\/[\w-?&;#~=\.\/\@]+[\w\/])/i","<a target=\"_blank\" href=\"$1\" target=\"_blank\">$1</a>",$tweetText);

					// twitter handles
					$tweetText = preg_replace('/(@\S+)/i',"<a target=\"_blank\" href=\"http://twitter.com/$1\" target=\"_blank\">$1</a>",$tweetText);

					// hash tags map to search?q=#hash
					$tweetText = preg_replace('/(#)(\S+)/i',"<a target=\"_blank\" href=\"http://twitter.com/search?q=%23$2\" target=\"_blank\">$1$2</a>",$tweetText);	

					echo '<li><a href="http://twitter.com/bbelderbos" target="_blank"><img src="'.$avatar.'" alt="bob avatar"></a><p>'.$tweetText . "</p></li>";
				}
				?>
			</ul>
		</div>
	</div>
</body>
</html>

