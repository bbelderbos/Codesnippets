<?php
$query = "select text,profile_image_url from twitter.search where q='from:@bbelderbos' limit 10";
$url = "http://query.yahooapis.com/v1/public/yql?q=";
$url .= rawurlencode($query);
$url .= "&format=json&env=store://datatables.org/alltableswithkeys";

// using curl, as file_get_contents sometimes fails on remote server
// $json = file_get_contents($url, true);
$json = get_data($url);

$info = json_decode($json, true) ;
// debug, if json_decode fails
// $error = json_last_error(); echo $error; exit;  
// debug, check structure result
// echo "<pre>"; print_r($info ); echo "</pre>"; exit; 

// function to get URL via cURL
// from: http://davidwalsh.name/download-urls-content-php-curl
function get_data($url) { 
  $ch = curl_init();
  $timeout = 5;
  curl_setopt($ch,CURLOPT_URL,$url);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
  curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);
  $data = curl_exec($ch);
  curl_close($ch);
  return $data;
}
?>
